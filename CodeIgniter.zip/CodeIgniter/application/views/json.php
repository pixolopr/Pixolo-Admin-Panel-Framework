<?php
print_r($message);
?>